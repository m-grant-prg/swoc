var cli_prg_2main_8c =
[
    [ "main", "cli-prg_2main_8c.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "prog_name", "cli-prg_2main_8c.html#a598d558168ea9fcc902baf4a3a42a5ea", null ]
];