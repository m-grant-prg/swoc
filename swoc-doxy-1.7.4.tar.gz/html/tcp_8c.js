var tcp_8c =
[
    [ "close_sock", "tcp_8c.html#a6372952c39dc68d7ddf5900119986544", null ],
    [ "est_connect", "tcp_8c.html#a585a293611d800b737668cd5f79d30b0", null ],
    [ "init_conn", "tcp_8c.html#a92d0cd7b20c558933fa38fc649bc6b69", null ],
    [ "listen_sock", "tcp_8c.html#ab982ee947f9bab0c4df1ed960eae1631", null ],
    [ "prep_recv_sock", "tcp_8c.html#a5c1902a68c3b13fc8fcb1840cd889dfb", null ]
];