var signalhandle_8h =
[
    [ "init_sig_handle", "signalhandle_8h.html#a232e7c4b65c794ff3adb68ac5a54b871", null ],
    [ "termination_handler", "signalhandle_8h.html#a57dae6bcf94a70cbe68aedc2a25f2286", null ]
];