var cmdlineargs_8h =
[
    [ "cla", "structcla.html", "structcla" ],
    [ "ARG_BUF", "cmdlineargs_8h.html#a2e37674a85ed2b026047e6d36ccf7703", null ],
    [ "cpyarg", "cmdlineargs_8h.html#af4e900bc4549a3f9887836289e77f684", null ],
    [ "process_cla", "cmdlineargs_8h.html#a9e4122b7d1eeb29932cf06d275c444d1", null ]
];