var searchData=
[
  ['end_42',['end',['../srv-prg_2swocserverd_2internal_8h.html#abce9f5dc9c83f2639b72024fdee5d388',1,'end():&#160;main.c'],['../srv-prg_2swocserverd_2main_8c.html#abce9f5dc9c83f2639b72024fdee5d388',1,'end():&#160;main.c']]],
  ['est_5fconnect_43',['est_connect',['../libswoccommon_8h.html#a585a293611d800b737668cd5f79d30b0',1,'est_connect(int *sfd, const char *serv, int *portno, struct addrinfo *hints, enum comms_mode *mode):&#160;tcp.c'],['../tcp_8c.html#a585a293611d800b737668cd5f79d30b0',1,'est_connect(int *sfd, const char *serv, int *portno, struct addrinfo *hints, enum comms_mode *mode):&#160;tcp.c']]],
  ['exch_5fmsg_44',['exch_msg',['../libswoccommon_8h.html#aa463dc8ce0737dbd04a660eaed009f71',1,'exch_msg(const char *outgoing_msg, size_t om_length, struct mgemessage *msg):&#160;messages.c'],['../messages_8c.html#aa463dc8ce0737dbd04a660eaed009f71',1,'exch_msg(const char *outgoing_msg, size_t om_length, struct mgemessage *msg):&#160;messages.c']]]
];
