var searchData=
[
  ['pollint_314',['pollint',['../libswoccommon_8h.html#a19bc6fbe245c7669861146c016c4189c',1,'pollint():&#160;validateconfig.c'],['../com-lib_2validateconfig_8c.html#acf8f1e5a20b0268b0ba18f635705856c',1,'pollint():&#160;validateconfig.c']]],
  ['port_5fsock_315',['port_sock',['../srv-prg_2swocserverd_2internal_8h.html#a7a03e90b559d0c6b8c97264a3bd5895e',1,'port_sock():&#160;internal.h'],['../srv-prg_2swocserverd_2main_8c.html#a119bf5995d19b05a922ce47a36f87e34',1,'port_sock():&#160;main.c']]],
  ['port_5fspec_316',['port_spec',['../srv-prg_2swocserverd_2internal_8h.html#a6b66903f2096d3408dbd17e4a3beaa61',1,'port_spec():&#160;main.c'],['../srv-prg_2swocserverd_2main_8c.html#a6b66903f2096d3408dbd17e4a3beaa61',1,'port_spec():&#160;main.c']]],
  ['portno_317',['portno',['../structcomm__spec.html#a59c2f683fd048491669fd79b2d45caf2',1,'comm_spec']]],
  ['prog_5fname_318',['prog_name',['../cli-prg_2main_8c.html#a598d558168ea9fcc902baf4a3a42a5ea',1,'prog_name():&#160;main.c'],['../srv-prg_2swocserver_2main_8c.html#a598d558168ea9fcc902baf4a3a42a5ea',1,'prog_name():&#160;main.c']]]
];
