var srv_prg_2swocserverd_2validateconfig_8c =
[
    [ "swsd_validate_config", "srv-prg_2swocserverd_2validateconfig_8c.html#a3a1cb47bcf11873ada2c05ff82c6d93c", null ],
    [ "validateportnos", "srv-prg_2swocserverd_2validateconfig_8c.html#ac6a36f30ab147a04db24b71d20976f05", null ]
];