var searchData=
[
  ['cli_5fblocked_322',['cli_blocked',['../srv-prg_2swocserverd_2internal_8h.html#a30194847c94f7bdcd5f811b469de5716',1,'cli_blocked():&#160;internal.h'],['../srv-prg_2swocserverd_2main_8c.html#ac475ea690c1a06206cbcbc70aa880316',1,'cli_blocked():&#160;main.c']]],
  ['cli_5flocks_323',['cli_locks',['../srv-prg_2swocserverd_2internal_8h.html#a682583ea4c2158a4bd61f25276b9891a',1,'cli_locks():&#160;main.c'],['../srv-prg_2swocserverd_2main_8c.html#a682583ea4c2158a4bd61f25276b9891a',1,'cli_locks():&#160;main.c']]],
  ['client_324',['client',['../srv-prg_2swocserverd_2internal_8h.html#a4a2953aa374b6ff1ae7a0d371075811a',1,'client():&#160;main.c'],['../srv-prg_2swocserverd_2main_8c.html#a4a2953aa374b6ff1ae7a0d371075811a',1,'client():&#160;main.c']]],
  ['cursockfd_325',['cursockfd',['../srv-prg_2swocserverd_2internal_8h.html#a737a44db750df5a116b85f42514c676d',1,'cursockfd():&#160;main.c'],['../srv-prg_2swocserverd_2main_8c.html#a737a44db750df5a116b85f42514c676d',1,'cursockfd():&#160;main.c']]]
];
