var searchData=
[
  ['max_5fepoll_5fevents_381',['MAX_EPOLL_EVENTS',['../srv-prg_2swocserverd_2internal_8h.html#afc006591e1289be0aef777083bf22b8a',1,'internal.h']]],
  ['max_5flisten_5fports_382',['MAX_LISTEN_PORTS',['../srv-prg_2swocserverd_2internal_8h.html#afa2f5e16e482bd83cfb15e8de131587d',1,'internal.h']]]
];
