var searchData=
[
  ['cla_195',['cla',['../structcla.html',1,'']]],
  ['comm_5fspec_196',['comm_spec',['../structcomm__spec.html',1,'']]]
];
