var srv_prg_2swocserver_2signalhandle_8c =
[
    [ "init_sig_handle", "srv-prg_2swocserver_2signalhandle_8c.html#a945da8b036ea7d42fbd47efb1cd23152", null ],
    [ "termination_handler", "srv-prg_2swocserver_2signalhandle_8c.html#a57dae6bcf94a70cbe68aedc2a25f2286", null ]
];