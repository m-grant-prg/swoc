var cli_lib_2libswocclient_2version_8c =
[
    [ "libswocclient_get_pkg_version", "cli-lib_2libswocclient_2version_8c.html#adb377dc0d89cc465791180bd068e6e82", null ],
    [ "libswocclient_get_src_version", "cli-lib_2libswocclient_2version_8c.html#affc539a810036644e5b64c6e27147684", null ],
    [ "libswocclient_print_pkg_version", "cli-lib_2libswocclient_2version_8c.html#a9cdade34fe54a52516ee857ebb2f7e8e", null ],
    [ "libswocclient_print_src_version", "cli-lib_2libswocclient_2version_8c.html#a3be4f6e6bd189ead318b00ae751c248a", null ]
];