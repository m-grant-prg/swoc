var srv_lib_2libswocserver_2version_8c =
[
    [ "libswocserver_get_pkg_version", "srv-lib_2libswocserver_2version_8c.html#a6d0fef18b90e1e52fc4dbbacd5f6ea01", null ],
    [ "libswocserver_get_src_version", "srv-lib_2libswocserver_2version_8c.html#a0369535858f44c9b8ac687392cc521b4", null ],
    [ "libswocserver_print_pkg_version", "srv-lib_2libswocserver_2version_8c.html#a5683c388cde0e3bd3e92806e4b25b0e6", null ],
    [ "libswocserver_print_src_version", "srv-lib_2libswocserver_2version_8c.html#aae83df00f7911e4be22d955b6c7063d4", null ]
];