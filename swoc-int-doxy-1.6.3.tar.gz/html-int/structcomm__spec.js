var structcomm__spec =
[
    [ "portno", "structcomm__spec.html#a59c2f683fd048491669fd79b2d45caf2", null ],
    [ "socketfd", "structcomm__spec.html#a16ece46816348fa6d2c5d0e8b47c0098", null ]
];