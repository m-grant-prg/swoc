var indexSectionsWithContent =
{
  0: "123_abcdefghilmoprstuv",
  1: "c",
  2: "123clmorstv",
  3: "_abcdeghilmoprstuv",
  4: "acdefilprs",
  5: "cm",
  6: "ars",
  7: "_abfst",
  8: "co"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros",
  8: "Pages"
};

