var searchData=
[
  ['bind_5fports_202',['bind_ports',['../comms_8c.html#af33b969ee2cb244d721551f3f7a3e969',1,'comms.c']]]
];
