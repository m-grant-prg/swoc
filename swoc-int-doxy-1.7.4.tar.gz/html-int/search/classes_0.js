var searchData=
[
  ['cla_187',['cla',['../structcla.html',1,'']]],
  ['comm_5fspec_188',['comm_spec',['../structcomm__spec.html',1,'']]]
];
