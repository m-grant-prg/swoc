var searchData=
[
  ['usage_294',['usage',['../cli-prg_2cmdlineargs_8c.html#af98c49d526205ce225e61f9f3ee4d23b',1,'usage(char **argv):&#160;cmdlineargs.c'],['../srv-prg_2swocserver_2cmdlineargs_8c.html#af98c49d526205ce225e61f9f3ee4d23b',1,'usage(char **argv):&#160;cmdlineargs.c']]]
];
