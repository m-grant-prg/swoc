var srv_prg_2swocserverd_2main_8c =
[
    [ "__bool_true_false_are_defined", "srv-prg_2swocserverd_2main_8c.html#a665b0cc9ee2ced31785321d55cde349e", null ],
    [ "_Bool", "srv-prg_2swocserverd_2main_8c.html#aeaff0db5524987a2f50d71ac0162ceb2", null ],
    [ "bool", "srv-prg_2swocserverd_2main_8c.html#abb452686968e48b67397da5f97445f5b", null ],
    [ "false", "srv-prg_2swocserverd_2main_8c.html#a65e9886d74aaee76545e83dd09011727", null ],
    [ "true", "srv-prg_2swocserverd_2main_8c.html#a41f9c5fb8b08eb5dc3edce4dcb37fee7", null ],
    [ "csscmp", "srv-prg_2swocserverd_2main_8c.html#a9004dc9694ba666a8f8111119a10a9c9", null ],
    [ "daemonise", "srv-prg_2swocserverd_2main_8c.html#a36b5bd4228b82fa576b895078dbcf4d9", null ],
    [ "main", "srv-prg_2swocserverd_2main_8c.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "cli_blocked", "srv-prg_2swocserverd_2main_8c.html#ac475ea690c1a06206cbcbc70aa880316", null ],
    [ "cli_locks", "srv-prg_2swocserverd_2main_8c.html#a682583ea4c2158a4bd61f25276b9891a", null ],
    [ "client", "srv-prg_2swocserverd_2main_8c.html#a4a2953aa374b6ff1ae7a0d371075811a", null ],
    [ "cursockfd", "srv-prg_2swocserverd_2main_8c.html#a737a44db750df5a116b85f42514c676d", null ],
    [ "debug", "srv-prg_2swocserverd_2main_8c.html#ac3e1795766a80ec63b157951b4b9a7d4", null ],
    [ "end", "srv-prg_2swocserverd_2main_8c.html#abce9f5dc9c83f2639b72024fdee5d388", null ],
    [ "port_sock", "srv-prg_2swocserverd_2main_8c.html#a119bf5995d19b05a922ce47a36f87e34", null ],
    [ "port_spec", "srv-prg_2swocserverd_2main_8c.html#a6b66903f2096d3408dbd17e4a3beaa61", null ],
    [ "srv_blocked", "srv-prg_2swocserverd_2main_8c.html#a48d1d3cb7faf21c6fbde4570294795e8", null ],
    [ "swsd_err", "srv-prg_2swocserverd_2main_8c.html#aea617ba9255dd59850aa1f68b6b0a8cd", null ]
];