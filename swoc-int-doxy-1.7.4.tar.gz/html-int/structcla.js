var structcla =
[
    [ "argument", "structcla.html#aa83f0bf952b55d16911431464b2d8fe5", null ],
    [ "is_set", "structcla.html#ac9c529f87d591772667e87c605e2233d", null ]
];