var srv_lib_2optionproc_8c =
[
    [ "__bool_true_false_are_defined", "srv-lib_2optionproc_8c.html#a665b0cc9ee2ced31785321d55cde349e", null ],
    [ "_Bool", "srv-lib_2optionproc_8c.html#aeaff0db5524987a2f50d71ac0162ceb2", null ],
    [ "bool", "srv-lib_2optionproc_8c.html#abb452686968e48b67397da5f97445f5b", null ],
    [ "false", "srv-lib_2optionproc_8c.html#a65e9886d74aaee76545e83dd09011727", null ],
    [ "true", "srv-lib_2optionproc_8c.html#a41f9c5fb8b08eb5dc3edce4dcb37fee7", null ],
    [ "sws_cli_block", "srv-lib_2optionproc_8c.html#ad517b6c7f3336a0e21b897a130136c6f", null ],
    [ "sws_cli_unblock", "srv-lib_2optionproc_8c.html#a7ea9a5f3641d19130f07670c43705c4c", null ],
    [ "sws_end_daemon", "srv-lib_2optionproc_8c.html#a13921e3aa7fed294a80ddce923dd85f8", null ],
    [ "sws_release", "srv-lib_2optionproc_8c.html#a93420228ed82c080ebf972c5000d8406", null ],
    [ "sws_reload_config", "srv-lib_2optionproc_8c.html#a86caa69b3d1c1a400bb72acffc601fa2", null ],
    [ "sws_server_wait", "srv-lib_2optionproc_8c.html#ab097377a58114d73c98fe50061e83c78", null ],
    [ "sws_show_block_status", "srv-lib_2optionproc_8c.html#a346bd39b05434056a131939ebb539163", null ],
    [ "sws_show_cli_blocklist", "srv-lib_2optionproc_8c.html#a490d9f8404a08def97cc33bc00e54ae1", null ],
    [ "sws_show_status", "srv-lib_2optionproc_8c.html#a1db9f9834d3afce58e87d7d646b7b989", null ],
    [ "sws_srv_block", "srv-lib_2optionproc_8c.html#a54b6477b1d7f5a6012c732bcf83dc155", null ],
    [ "sws_srv_unblock", "srv-lib_2optionproc_8c.html#a09d2290fb2c5cf056380f2ec721adb2f", null ],
    [ "locks_held", "srv-lib_2optionproc_8c.html#a55957b815ac9e4684f6b9dc1d91a2cf8", null ]
];