var searchData=
[
  ['parse_5fmsg_249',['parse_msg',['../libswoccommon_8h.html#a4052ba9bf4315c744ca2f45d8d14358f',1,'parse_msg(struct mgemessage *msg, enum msg_arguments *msg_args, enum msg_source *msg_src, enum msg_request *msg_req):&#160;messages.c'],['../messages_8c.html#a4052ba9bf4315c744ca2f45d8d14358f',1,'parse_msg(struct mgemessage *msg, enum msg_arguments *msg_args, enum msg_source *msg_src, enum msg_request *msg_req):&#160;messages.c']]],
  ['prep_5frecv_5fsock_250',['prep_recv_sock',['../libswoccommon_8h.html#a5c1902a68c3b13fc8fcb1840cd889dfb',1,'prep_recv_sock(int *sockfd, int *portno):&#160;tcp.c'],['../tcp_8c.html#a5c1902a68c3b13fc8fcb1840cd889dfb',1,'prep_recv_sock(int *sockfd, int *portno):&#160;tcp.c']]],
  ['prepare_5fsockets_251',['prepare_sockets',['../comms_8c.html#aef1b017a8c30cc28e880eb1982456b11',1,'comms.c']]],
  ['proc_5fevents_252',['proc_events',['../comms_8c.html#a6ea7e9ee19702d2d99b1701b724990f7',1,'comms.c']]],
  ['proc_5fmsg_253',['proc_msg',['../comms_8c.html#aadec1e9bb7a8c0a3eec70a8c45807b44',1,'comms.c']]],
  ['process_5fcla_254',['process_cla',['../cmdlineargs_8h.html#a9e4122b7d1eeb29932cf06d275c444d1',1,'process_cla(int argc, char **argv,...):&#160;cmdlineargs.c'],['../cli-prg_2cmdlineargs_8c.html#a9e4122b7d1eeb29932cf06d275c444d1',1,'process_cla(int argc, char **argv,...):&#160;cmdlineargs.c'],['../srv-prg_2swocserver_2cmdlineargs_8c.html#a9e4122b7d1eeb29932cf06d275c444d1',1,'process_cla(int argc, char **argv,...):&#160;cmdlineargs.c'],['../srv-prg_2swocserverd_2cmdlineargs_8c.html#a9e4122b7d1eeb29932cf06d275c444d1',1,'process_cla(int argc, char **argv,...):&#160;cmdlineargs.c']]],
  ['process_5fcomms_255',['process_comms',['../comms_8c.html#aeb9deebda7c6e6e0108ad5e5e341906c',1,'comms.c']]]
];
