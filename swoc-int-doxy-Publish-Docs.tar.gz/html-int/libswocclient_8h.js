var libswocclient_8h =
[
    [ "libswocclient_get_pkg_version", "libswocclient_8h.html#adb377dc0d89cc465791180bd068e6e82", null ],
    [ "libswocclient_get_src_version", "libswocclient_8h.html#affc539a810036644e5b64c6e27147684", null ],
    [ "libswocclient_print_pkg_version", "libswocclient_8h.html#a9cdade34fe54a52516ee857ebb2f7e8e", null ],
    [ "libswocclient_print_src_version", "libswocclient_8h.html#a3be4f6e6bd189ead318b00ae751c248a", null ],
    [ "swc_block", "libswocclient_8h.html#ab4f43f303d2adeb9e60c13fd851c28f7", null ],
    [ "swc_client_wait", "libswocclient_8h.html#a8a84c7270705bb94aa755fa48c563a32", null ],
    [ "swc_rel_lock", "libswocclient_8h.html#adf509cf55cccde625d4914acc9767e1a", null ],
    [ "swc_reset", "libswocclient_8h.html#a97c14b81969fc3fd9f6d757a2446c2f4", null ],
    [ "swc_set_lock", "libswocclient_8h.html#a85d39aaee4c270451d0f7758c6206b06", null ],
    [ "swc_show_srv_block_status", "libswocclient_8h.html#ac9216a291bc0188cb85274fd5cb054dc", null ],
    [ "swc_show_status", "libswocclient_8h.html#abee3a062bf6ed9fede2a8f87e1e503fc", null ],
    [ "swc_unblock", "libswocclient_8h.html#ad1907b88936cb1ca6d6d8d27ee8b42f7", null ],
    [ "locks_held", "libswocclient_8h.html#a29cd59bd1ea501b097f5d2b1d8cf00e8", null ]
];