var searchData=
[
  ['id_5freq_241',['id_req',['../srv-prg_2swocserverd_2internal_8h.html#a2fdb5e524caad40f097572cf6321ed00',1,'id_req(struct mgemessage *msg, enum msg_arguments *msg_args):&#160;request.c'],['../request_8c.html#a2fdb5e524caad40f097572cf6321ed00',1,'id_req(struct mgemessage *msg, enum msg_arguments *msg_args):&#160;request.c']]],
  ['init_5fconn_242',['init_conn',['../libswoccommon_8h.html#a89caea0bfb932ee6b30716791f8a7452',1,'init_conn(int *sockfd, int *portno, char *srv):&#160;tcp.c'],['../tcp_8c.html#a89caea0bfb932ee6b30716791f8a7452',1,'init_conn(int *sockfd, int *portno, char *srv):&#160;tcp.c']]],
  ['init_5fepoll_243',['init_epoll',['../comms_8c.html#ae6b35ebb513d54ff28799fd9c60241c0',1,'comms.c']]],
  ['init_5fsig_5fhandle_244',['init_sig_handle',['../signalhandle_8h.html#a232e7c4b65c794ff3adb68ac5a54b871',1,'init_sig_handle(void):&#160;signalhandle.c'],['../cli-prg_2signalhandle_8c.html#a945da8b036ea7d42fbd47efb1cd23152',1,'init_sig_handle(void):&#160;signalhandle.c'],['../srv-prg_2swocserver_2signalhandle_8c.html#a945da8b036ea7d42fbd47efb1cd23152',1,'init_sig_handle(void):&#160;signalhandle.c'],['../srv-prg_2swocserverd_2signalhandle_8c.html#a945da8b036ea7d42fbd47efb1cd23152',1,'init_sig_handle(void):&#160;signalhandle.c']]]
];
