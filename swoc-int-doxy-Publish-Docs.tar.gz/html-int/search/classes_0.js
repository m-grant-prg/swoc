var searchData=
[
  ['cla_197',['cla',['../structcla.html',1,'']]],
  ['comm_5fspec_198',['comm_spec',['../structcomm__spec.html',1,'']]]
];
