var searchData=
[
  ['cli_5fblocked_273',['cli_blocked',['../srv-prg_2swocserverd_2main_8c.html#ac475ea690c1a06206cbcbc70aa880316',1,'main.c']]],
  ['cli_5flocks_274',['cli_locks',['../srv-prg_2swocserverd_2main_8c.html#a682583ea4c2158a4bd61f25276b9891a',1,'main.c']]],
  ['client_275',['client',['../srv-prg_2swocserverd_2main_8c.html#a4a2953aa374b6ff1ae7a0d371075811a',1,'main.c']]],
  ['cursockfd_276',['cursockfd',['../srv-prg_2swocserverd_2main_8c.html#a737a44db750df5a116b85f42514c676d',1,'main.c']]]
];
