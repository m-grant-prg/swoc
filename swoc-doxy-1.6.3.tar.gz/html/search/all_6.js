var searchData=
[
  ['cli_5fblock_5freq_9',['cli_block_req',['../request_8c.html#a1652b6de52491ad1f8e12c257581fd85',1,'request.c']]],
  ['cli_5fblocked_10',['cli_blocked',['../srv-prg_2swocserverd_2main_8c.html#ac475ea690c1a06206cbcbc70aa880316',1,'main.c']]],
  ['cli_5flock_5freq_11',['cli_lock_req',['../request_8c.html#ab32e47f9977cb00980cd8d7f0edd958b',1,'request.c']]],
  ['cli_5flocks_12',['cli_locks',['../srv-prg_2swocserverd_2main_8c.html#a682583ea4c2158a4bd61f25276b9891a',1,'main.c']]],
  ['cli_5frel_5freq_13',['cli_rel_req',['../request_8c.html#ad9fec54f9a4608475e0452fd7b55b1b5',1,'request.c']]],
  ['cli_5freset_5freq_14',['cli_reset_req',['../request_8c.html#a1a1cda43fb792ccb8b2fb4ba5eb1b593',1,'request.c']]],
  ['cli_5fsrv_5fblock_5fstatus_5freq_15',['cli_srv_block_status_req',['../request_8c.html#a1f152a6379c32e487092e17be4656c66',1,'request.c']]],
  ['cli_5fstatus_5freq_16',['cli_status_req',['../request_8c.html#a54648dce7153ce84b0171c43a88a65e7',1,'request.c']]],
  ['cli_5funblock_5freq_17',['cli_unblock_req',['../request_8c.html#aa9fbf1e75be092ec5a123de895aaddef',1,'request.c']]],
  ['client_18',['client',['../srv-prg_2swocserverd_2main_8c.html#a4a2953aa374b6ff1ae7a0d371075811a',1,'main.c']]],
  ['close_5fsock_19',['close_sock',['../tcp_8c.html#a6372952c39dc68d7ddf5900119986544',1,'tcp.c']]],
  ['close_5fssh_5ftunnel_20',['close_ssh_tunnel',['../ssh_8c.html#add62324565a944f940d309a189f92f86',1,'ssh.c']]],
  ['cmdlineargs_2ec_21',['cmdlineargs.c',['../cli-prg_2swocclient_2cmdlineargs_8c.html',1,'(Global Namespace)'],['../srv-prg_2swocserver_2cmdlineargs_8c.html',1,'(Global Namespace)'],['../srv-prg_2swocserverd_2cmdlineargs_8c.html',1,'(Global Namespace)']]],
  ['comms_2ec_22',['comms.c',['../comms_8c.html',1,'']]],
  ['cpyarg_23',['cpyarg',['../cli-prg_2swocclient_2cmdlineargs_8c.html#af4e900bc4549a3f9887836289e77f684',1,'cpyarg(char *flagarg, char *srcarg):&#160;cmdlineargs.c'],['../srv-prg_2swocserver_2cmdlineargs_8c.html#af4e900bc4549a3f9887836289e77f684',1,'cpyarg(char *flagarg, char *srcarg):&#160;cmdlineargs.c']]],
  ['csscmp_24',['csscmp',['../srv-prg_2swocserverd_2main_8c.html#a9004dc9694ba666a8f8111119a10a9c9',1,'main.c']]],
  ['cursockfd_25',['cursockfd',['../srv-prg_2swocserverd_2main_8c.html#a737a44db750df5a116b85f42514c676d',1,'main.c']]],
  ['common_20library_26',['Common Library',['../md_docs_doxygen_src_200-common-lib.html',1,'']]],
  ['client_20library_27',['Client Library',['../md_docs_doxygen_src_300-client-lib.html',1,'']]]
];
