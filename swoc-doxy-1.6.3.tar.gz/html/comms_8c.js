var comms_8c =
[
    [ "__bool_true_false_are_defined", "comms_8c.html#a665b0cc9ee2ced31785321d55cde349e", null ],
    [ "_Bool", "comms_8c.html#aeaff0db5524987a2f50d71ac0162ceb2", null ],
    [ "bool", "comms_8c.html#abb452686968e48b67397da5f97445f5b", null ],
    [ "false", "comms_8c.html#a65e9886d74aaee76545e83dd09011727", null ],
    [ "true", "comms_8c.html#a41f9c5fb8b08eb5dc3edce4dcb37fee7", null ],
    [ "bind_ports", "comms_8c.html#af33b969ee2cb244d721551f3f7a3e969", null ],
    [ "init_epoll", "comms_8c.html#ae6b35ebb513d54ff28799fd9c60241c0", null ],
    [ "prepare_sockets", "comms_8c.html#aef1b017a8c30cc28e880eb1982456b11", null ],
    [ "proc_events", "comms_8c.html#a6ea7e9ee19702d2d99b1701b724990f7", null ],
    [ "proc_msg", "comms_8c.html#aadec1e9bb7a8c0a3eec70a8c45807b44", null ],
    [ "process_comms", "comms_8c.html#aeb9deebda7c6e6e0108ad5e5e341906c", null ]
];