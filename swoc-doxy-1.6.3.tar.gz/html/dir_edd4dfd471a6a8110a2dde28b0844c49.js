var dir_edd4dfd471a6a8110a2dde28b0844c49 =
[
    [ "optionproc.c", "srv-lib_2libswocserver_2optionproc_8c.html", "srv-lib_2libswocserver_2optionproc_8c" ],
    [ "version.c", "srv-lib_2libswocserver_2version_8c.html", "srv-lib_2libswocserver_2version_8c" ]
];