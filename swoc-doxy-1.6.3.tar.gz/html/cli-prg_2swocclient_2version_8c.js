var cli_prg_2swocclient_2version_8c =
[
    [ "swocclient_get_pkg_version", "cli-prg_2swocclient_2version_8c.html#a5c8c2221ef3aaffd3ac1f6a1945b6b62", null ],
    [ "swocclient_get_src_version", "cli-prg_2swocclient_2version_8c.html#ac35c664513620f269ef3232b74a28d8d", null ],
    [ "swocclient_print_pkg_version", "cli-prg_2swocclient_2version_8c.html#af4bc24cb5f2d7e9d2fc8c5ee1ada06c9", null ],
    [ "swocclient_print_src_version", "cli-prg_2swocclient_2version_8c.html#a3f6834ddd5c52fe8c446b23e9cebf0ea", null ]
];