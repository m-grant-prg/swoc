var dir_2a80efaaa274f877ebf3473506653d28 =
[
    [ "cmdlineargs.c", "srv-prg_2swocserver_2cmdlineargs_8c.html", "srv-prg_2swocserver_2cmdlineargs_8c" ],
    [ "internal.h", "srv-prg_2swocserver_2internal_8h.html", "srv-prg_2swocserver_2internal_8h" ],
    [ "main.c", "srv-prg_2swocserver_2main_8c.html", "srv-prg_2swocserver_2main_8c" ],
    [ "signalhandle.c", "srv-prg_2swocserver_2signalhandle_8c.html", "srv-prg_2swocserver_2signalhandle_8c" ],
    [ "version.c", "srv-prg_2swocserver_2version_8c.html", "srv-prg_2swocserver_2version_8c" ]
];