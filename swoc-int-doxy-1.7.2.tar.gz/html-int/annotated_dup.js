var annotated_dup =
[
    [ "cla", "structcla.html", "structcla" ],
    [ "comm_spec", "structcomm__spec.html", "structcomm__spec" ]
];