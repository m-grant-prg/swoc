var searchData=
[
  ['parse_5fmsg_234',['parse_msg',['../libswoccommon_8h.html#a4052ba9bf4315c744ca2f45d8d14358f',1,'parse_msg(struct mgemessage *msg, enum msg_arguments *msg_args, enum msg_source *msg_src, enum msg_request *msg_req):&#160;messages.c'],['../messages_8c.html#a4052ba9bf4315c744ca2f45d8d14358f',1,'parse_msg(struct mgemessage *msg, enum msg_arguments *msg_args, enum msg_source *msg_src, enum msg_request *msg_req):&#160;messages.c']]],
  ['prep_5frecv_5fsock_235',['prep_recv_sock',['../libswoccommon_8h.html#a5c1902a68c3b13fc8fcb1840cd889dfb',1,'prep_recv_sock(int *sockfd, int *portno):&#160;tcp.c'],['../tcp_8c.html#a5c1902a68c3b13fc8fcb1840cd889dfb',1,'prep_recv_sock(int *sockfd, int *portno):&#160;tcp.c']]],
  ['prepare_5fsockets_236',['prepare_sockets',['../comms_8c.html#aef1b017a8c30cc28e880eb1982456b11',1,'comms.c']]],
  ['proc_5fevents_237',['proc_events',['../comms_8c.html#a6ea7e9ee19702d2d99b1701b724990f7',1,'comms.c']]],
  ['proc_5fmsg_238',['proc_msg',['../comms_8c.html#a15cdd395a4c5993564707e78b540b5c4',1,'comms.c']]],
  ['process_5fcla_239',['process_cla',['../cmdlineargs_8h.html#a9e4122b7d1eeb29932cf06d275c444d1',1,'process_cla(int argc, char **argv,...):&#160;cmdlineargs.c'],['../cli-prg_2cmdlineargs_8c.html#a9e4122b7d1eeb29932cf06d275c444d1',1,'process_cla(int argc, char **argv,...):&#160;cmdlineargs.c'],['../srv-prg_2swocserver_2cmdlineargs_8c.html#a9e4122b7d1eeb29932cf06d275c444d1',1,'process_cla(int argc, char **argv,...):&#160;cmdlineargs.c'],['../srv-prg_2swocserverd_2cmdlineargs_8c.html#a9e4122b7d1eeb29932cf06d275c444d1',1,'process_cla(int argc, char **argv,...):&#160;cmdlineargs.c']]],
  ['process_5fcomms_240',['process_comms',['../comms_8c.html#aeb9deebda7c6e6e0108ad5e5e341906c',1,'comms.c']]]
];
