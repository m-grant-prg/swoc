var searchData=
[
  ['parse_5fmsg_72',['parse_msg',['../messages_8c.html#a4052ba9bf4315c744ca2f45d8d14358f',1,'parse_msg(struct mgemessage *msg, enum msg_arguments *msg_args, enum msg_source *msg_src, enum msg_request *msg_req):&#160;messages.c'],['../libswoccommon_8h.html#a4052ba9bf4315c744ca2f45d8d14358f',1,'parse_msg(struct mgemessage *msg, enum msg_arguments *msg_args, enum msg_source *msg_src, enum msg_request *msg_req):&#160;messages.c']]],
  ['pollint_73',['pollint',['../libswoccommon_8h.html#a19bc6fbe245c7669861146c016c4189c',1,'pollint():&#160;validateconfig.c'],['../com-lib_2validateconfig_8c.html#acf8f1e5a20b0268b0ba18f635705856c',1,'pollint():&#160;validateconfig.c']]],
  ['port_5fsock_74',['port_sock',['../srv-prg_2swocserverd_2main_8c.html#a119bf5995d19b05a922ce47a36f87e34',1,'main.c']]],
  ['port_5fspec_75',['port_spec',['../srv-prg_2swocserverd_2main_8c.html#a6b66903f2096d3408dbd17e4a3beaa61',1,'main.c']]],
  ['prep_5frecv_5fsock_76',['prep_recv_sock',['../libswoccommon_8h.html#a5c1902a68c3b13fc8fcb1840cd889dfb',1,'prep_recv_sock(int *sockfd, int *portno):&#160;tcp.c'],['../tcp_8c.html#a5c1902a68c3b13fc8fcb1840cd889dfb',1,'prep_recv_sock(int *sockfd, int *portno):&#160;tcp.c']]],
  ['prepare_5fsockets_77',['prepare_sockets',['../comms_8c.html#aef1b017a8c30cc28e880eb1982456b11',1,'comms.c']]],
  ['proc_5fevents_78',['proc_events',['../comms_8c.html#a6ea7e9ee19702d2d99b1701b724990f7',1,'comms.c']]],
  ['proc_5fmsg_79',['proc_msg',['../comms_8c.html#aadec1e9bb7a8c0a3eec70a8c45807b44',1,'comms.c']]],
  ['process_5fcla_80',['process_cla',['../cmdlineargs_8h.html#a9e4122b7d1eeb29932cf06d275c444d1',1,'process_cla(int argc, char **argv,...):&#160;cmdlineargs.c'],['../cli-prg_2cmdlineargs_8c.html#a9e4122b7d1eeb29932cf06d275c444d1',1,'process_cla(int argc, char **argv,...):&#160;cmdlineargs.c'],['../srv-prg_2swocserver_2cmdlineargs_8c.html#a9e4122b7d1eeb29932cf06d275c444d1',1,'process_cla(int argc, char **argv,...):&#160;cmdlineargs.c'],['../srv-prg_2swocserverd_2cmdlineargs_8c.html#a9e4122b7d1eeb29932cf06d275c444d1',1,'process_cla(int argc, char **argv,...):&#160;cmdlineargs.c']]],
  ['process_5fcomms_81',['process_comms',['../comms_8c.html#aeb9deebda7c6e6e0108ad5e5e341906c',1,'comms.c']]],
  ['prog_5fname_82',['prog_name',['../cli-prg_2main_8c.html#a598d558168ea9fcc902baf4a3a42a5ea',1,'prog_name():&#160;main.c'],['../srv-prg_2swocserver_2main_8c.html#a598d558168ea9fcc902baf4a3a42a5ea',1,'prog_name():&#160;main.c']]]
];
