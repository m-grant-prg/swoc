var cli_lib_2version_8c =
[
    [ "__attribute__", "cli-lib_2version_8c.html#a699f6a3da91f9155d09cd12158ed6def", null ],
    [ "libswocclient_print_pkg_version", "cli-lib_2version_8c.html#a9cdade34fe54a52516ee857ebb2f7e8e", null ],
    [ "libswocclient_print_src_version", "cli-lib_2version_8c.html#a3be4f6e6bd189ead318b00ae751c248a", null ]
];