var srv_prg_2swocserverd_2version_8c =
[
    [ "swocserverd_get_pkg_version", "srv-prg_2swocserverd_2version_8c.html#af688b71c720d72e617183c0209803b79", null ],
    [ "swocserverd_get_src_version", "srv-prg_2swocserverd_2version_8c.html#a8f2668031be3b14ddc8c34df86bf6683", null ],
    [ "swocserverd_print_pkg_version", "srv-prg_2swocserverd_2version_8c.html#ae32be5ad8c80104919dd3163cbfb31e5", null ],
    [ "swocserverd_print_src_version", "srv-prg_2swocserverd_2version_8c.html#aca00cde93a5977755936d23ab9550859", null ]
];