var srv_prg_2swocserver_2version_8c =
[
    [ "swocserver_get_pkg_version", "srv-prg_2swocserver_2version_8c.html#a16f39211acafec0933ebad4efef9211e", null ],
    [ "swocserver_get_src_version", "srv-prg_2swocserver_2version_8c.html#a75337b6c273b7d2a136c6b5fa0f402dd", null ],
    [ "swocserver_print_pkg_version", "srv-prg_2swocserver_2version_8c.html#a30df115e56f190f8186bab9db905a497", null ],
    [ "swocserver_print_src_version", "srv-prg_2swocserver_2version_8c.html#a15db510fd06d6e9ae3f914ff5e9c6b3c", null ]
];