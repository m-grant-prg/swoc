var searchData=
[
  ['est_5fconnect_236',['est_connect',['../libswoccommon_8h.html#ab2ef757fb2d61d186fd48e162faf7806',1,'est_connect(int *sfd, char *serv, int *portno, struct addrinfo *hints, enum comms_mode *mode):&#160;tcp.c'],['../tcp_8c.html#ab2ef757fb2d61d186fd48e162faf7806',1,'est_connect(int *sfd, char *serv, int *portno, struct addrinfo *hints, enum comms_mode *mode):&#160;tcp.c']]],
  ['exch_5fmsg_237',['exch_msg',['../libswoccommon_8h.html#a68fbd6fad819fd3943528a9eb0964f24',1,'exch_msg(char *outgoing_msg, size_t om_length, struct mgemessage *msg):&#160;messages.c'],['../messages_8c.html#a68fbd6fad819fd3943528a9eb0964f24',1,'exch_msg(char *outgoing_msg, size_t om_length, struct mgemessage *msg):&#160;messages.c']]]
];
